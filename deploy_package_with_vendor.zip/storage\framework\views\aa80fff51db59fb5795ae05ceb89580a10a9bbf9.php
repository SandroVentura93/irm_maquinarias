

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Rol</h1>

    <form action="<?php echo e(route('roles.update', $rol)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($rol->nombre); ?>" required>
        </div>

        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" class="form-control"><?php echo e($rol->descripcion); ?></textarea>
        </div>

        <div class="form-group form-check">
            <input type="checkbox" name="activo" id="activo" class="form-check-input" <?php echo e($rol->activo ? 'checked' : ''); ?>>
            <label for="activo" class="form-check-label">Activo</label>
        </div>

        <button type="submit" class="btn btn-primary">Actualizar</button>
        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\roles\edit.blade.php ENDPATH**/ ?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>IRM Maquinarias S.R.L. - Dashboard</title>
    
    <!-- Bootstrap 5 y librerías modernas -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <!-- Google Fonts para tipografía moderna -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Animate.css para animaciones -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    
    <style>
        :root {
            --primary-color: #4f46e5;
            --primary-dark: #4338ca;
            --primary-light: #6366f1;
            --secondary-color: #0ea5e9;
            --success-color: #10b981;
            --warning-color: #f59e0b;
            --danger-color: #ef4444;
            --dark-bg: #1e293b;
            --darker-bg: #0f172a;
            --sidebar-bg: linear-gradient(180deg, #1e293b 0%, #0f172a 100%);
            --text-light: #f1f5f9;
            --text-muted: #94a3b8;
            --border-color: #334155;
            --hover-bg: #334155;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
            --shadow-xl: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
        }
        
        body {
            display: flex;
            min-height: 100vh;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            background-attachment: fixed;
            overflow-x: hidden;
        }

        /* Navbar superior mejorada */
        .top-navbar {
            position: fixed;
            top: 0;
            left: 280px;
            right: 0;
            height: 70px;
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            box-shadow: var(--shadow-md);
            z-index: 1000;
            display: flex;
            align-items: center;
            padding: 0 30px;
            border-bottom: 1px solid rgba(0, 0, 0, 0.08);
        }

        .top-navbar .logo-text {
            font-family: 'Poppins', sans-serif;
            font-size: 1.5rem;
            font-weight: 700;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* Mobile sidebar toggler */
        .sidebar-toggler{
            display:none;
            background: linear-gradient(135deg,var(--primary-color),var(--primary-light));
            border:none;color:white;padding:8px 10px;border-radius:8px;align-items:center;justify-content:center;cursor:pointer;
            box-shadow:var(--shadow-sm);
        }

        @media (max-width: 768px){
            .sidebar-toggler{display:flex;margin-right:12px}
            .top-navbar .logo-text{margin-left:6px}
        }

        .top-navbar .user-info {
            margin-left: auto;
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .top-navbar .welcome-text {
            font-size: 0.95rem;
            color: #64748b;
        }

        .top-navbar .user-name {
            font-weight: 600;
            color: var(--dark-bg);
            font-size: 1rem;
        }

        .top-navbar .btn-logout {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-light));
            color: white;
            border: none;
            padding: 10px 24px;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
            box-shadow: var(--shadow-sm);
        }

        /* Mostrar solo el icono de cerrar sesión en móviles */
        .top-navbar .btn-logout .logout-text{display:inline}
        @media (max-width:768px){
            .top-navbar .btn-logout{padding:8px 10px}
            .top-navbar .btn-logout .logout-text{display:none}
        }

        .top-navbar .btn-logout:hover {
            transform: translateY(-2px);
            box-shadow: var(--shadow-lg);
            background: linear-gradient(135deg, var(--primary-dark), var(--primary-color));
        }

        /* Sidebar moderna y elegante */
        .sidebar {
            width: 280px;
            background: var(--sidebar-bg);
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            padding: 0;
            overflow-y: auto;
            box-shadow: var(--shadow-xl);
            z-index: 1001;
        }

        .sidebar::-webkit-scrollbar {
            width: 6px;
        }

        .sidebar::-webkit-scrollbar-track {
            background: var(--darker-bg);
        }

        .sidebar::-webkit-scrollbar-thumb {
            background: var(--border-color);
            border-radius: 3px;
        }

        .sidebar::-webkit-scrollbar-thumb:hover {
            background: var(--hover-bg);
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid var(--border-color);
            background: rgba(79, 70, 229, 0.1);
        }

        .sidebar-header .brand {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            margin-bottom: 8px;
        }

        .sidebar-header .brand-icon {
            width: 45px;
            height: 45px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
            box-shadow: var(--shadow-md);
        }

        .sidebar-header h4 {
            font-family: 'Poppins', sans-serif;
            color: var(--text-light);
            font-size: 1.4rem;
            font-weight: 700;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .sidebar-header .brand-tagline {
            color: var(--text-muted);
            font-size: 0.75rem;
            font-weight: 400;
            margin-top: 4px;
        }

        .sidebar-nav {
            padding: 20px 15px;
        }

        .nav-section-title {
            color: var(--text-muted);
            font-size: 0.7rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            padding: 15px 15px 10px;
            margin-top: 10px;
        }

        .nav-item {
            margin: 4px 0;
        }

        .nav-link {
            color: var(--text-muted);
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 12px 15px;
            border-radius: 10px;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            font-weight: 500;
            font-size: 0.95rem;
            position: relative;
            overflow: hidden;
        }

        .nav-link::before {
            content: '';
            position: absolute;
            left: 0;
            top: 0;
            bottom: 0;
            width: 3px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            transform: scaleY(0);
            transition: transform 0.3s ease;
        }

        .nav-link:hover {
            background: var(--hover-bg);
            color: var(--text-light);
            transform: translateX(5px);
            box-shadow: var(--shadow-sm);
        }

        .nav-link:hover::before {
            transform: scaleY(1);
        }

        .nav-link.active {
            background: linear-gradient(135deg, rgba(79, 70, 229, 0.2), rgba(14, 165, 233, 0.2));
            color: var(--text-light);
            box-shadow: var(--shadow-md);
            border-left: 3px solid var(--primary-color);
        }

        .nav-link i {
            margin-right: 12px;
            width: 20px;
            font-size: 1.1rem;
            text-align: center;
        }

        /* Menús colapsables mejorados */
        .menu-item {
            margin: 8px 0;
        }

        .menu-item h5 {
            cursor: pointer;
            margin: 0;
            padding: 12px 15px;
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-light);
            border-radius: 10px;
            font-size: 0.95rem;
            font-weight: 600;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: space-between;
            border: 1px solid transparent;
        }

        .menu-item h5:hover {
            background: var(--hover-bg);
            border-color: var(--border-color);
            transform: translateX(3px);
        }

        .menu-item h5::after {
            content: '\f107';
            font-family: 'Font Awesome 6 Free';
            font-weight: 900;
            transition: transform 0.3s ease;
            font-size: 0.85rem;
            color: var(--text-muted);
        }

        .menu-item.open h5::after {
            transform: rotate(180deg);
        }

        .submenu {
            display: none;
            margin-top: 5px;
            margin-left: 10px;
            padding-left: 10px;
            border-left: 2px solid var(--border-color);
        }

        .submenu a {
            color: var(--text-muted);
            text-decoration: none;
            display: flex;
            align-items: center;
            padding: 10px 15px;
            margin: 2px 0;
            border-radius: 8px;
            font-size: 0.9rem;
            transition: all 0.3s ease;
            font-weight: 400;
        }

        .submenu a:hover {
            background: rgba(255, 255, 255, 0.08);
            color: var(--text-light);
            transform: translateX(5px);
        }

        .submenu a i {
            margin-right: 10px;
            width: 18px;
            font-size: 0.95rem;
            text-align: center;
        }

        /* Área de contenido */
        .content {
            margin-left: 280px;
            margin-top: 70px;
            padding: 30px;
            flex: 1;
            min-height: calc(100vh - 70px);
        }

        .content-wrapper {
            background: white;
            border-radius: 16px;
            padding: 30px;
            box-shadow: var(--shadow-xl);
            min-height: calc(100vh - 130px);
        }

        /* Animaciones */
        @keyframes  slideDown {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes  fadeIn {
            from {
                opacity: 0;
            }
            to {
                opacity: 1;
            }
        }

        .animate-in {
            animation: fadeIn 0.5s ease-out;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }

            .sidebar.show {
                transform: translateX(0);
            }

            .content {
                margin-left: 0;
            }

            .top-navbar {
                left: 0;
            }
        }
        /* Additional top-navbar responsiveness */
        @media (max-width: 992px) {
            .top-navbar { height: 60px; padding: 0 16px; }
            .top-navbar .logo-text { font-size: 1.2rem; }
            .top-navbar .user-info { gap: 12px; }
        }

        @media (max-width: 768px) {
            .top-navbar { height: 56px; padding: 0 12px; }
            .top-navbar .logo-text { font-size: 1.05rem; white-space: normal; line-height: 1; }
            .top-navbar .logo-text i { font-size: 1.05rem; }
            .top-navbar .welcome-text { display: none; }
            .top-navbar .user-name { font-size: 0.95rem; max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
            .top-navbar .user-info { gap: 8px; align-items: center; }
            .top-navbar .btn-logout { padding: 8px; }
            .sidebar-toggler { margin-right: 8px; }
        }

        @media (max-width: 480px) {
            .top-navbar { height: 52px; padding: 0 8px; }
            .top-navbar .logo-text { font-size: 0.95rem; }
            .top-navbar .logo-text i { font-size: 1rem; }
            /* hide username on very small screens to free space */
            .top-navbar .user-name { display: none; }
            /* keep only the logout icon visible */
            .top-navbar .btn-logout { padding: 6px; }
            .top-navbar .btn-logout .logout-text { display: none !important; }
            .top-navbar .btn-logout i { font-size: 1rem; }
        }
        /* Additional mobile-friendly adjustments */
        @media (max-width: 992px) {
            .content-wrapper { padding: 20px; border-radius: 12px; }
            .container-fluid { padding-left: 16px; padding-right: 16px; }
        }

        @media (max-width: 768px) {
            .content { padding: 12px; margin-top: 70px; }
            .content-wrapper { padding: 12px; border-radius: 8px; box-shadow: none; min-height: auto; }
            .content .content-wrapper { max-width: 100%; }
            /* Make page header wrap instead of overflow */
            .page-header { flex-wrap: wrap; gap: 0.5rem; }
            .page-title { font-size: 1.25rem; }
            /* Reduce card radius for full-bleed feel on small screens */
            .card-modern { border-radius: 8px; }
            /* Reduce top navbar padding to free horizontal space */
            .top-navbar { padding: 0 12px; }
            /* Ensure container spacing is not excessive on very small devices */
            .container-fluid.px-4.py-4 { padding-left: 8px; padding-right: 8px; }
        }
        /* Global responsive helpers */
        /* Ensure images never overflow their containers */
        .img-fluid, img { max-width:100%; height:auto; display:block; }

        /* Make tables scrollable and responsive on small screens only */
        .table-responsive{ overflow:auto; -webkit-overflow-scrolling: touch; }
        /* Ensure any table inside the main content becomes scrollable on small screens without editing each view */
        @media (max-width: 992px) {
            .content .content-wrapper table{
                display:block;
                width:100%;
                overflow:auto;
                -webkit-overflow-scrolling:touch;
            }
            .content .content-wrapper table td, .content .content-wrapper table th{ white-space:nowrap }
        }

        /* Make inline form controls stack on small screens */
        @media (max-width: 768px){
            .form-inline .form-control{ width:100%; margin-bottom:.5rem; }
            .content-wrapper{ padding:18px }
        }
    </style>
</head>
<body>
    <!-- Navbar Superior -->
    <div class="top-navbar animate-in">
            <div style="display:flex;align-items:center;gap:8px">
            <!-- Mobile toggler to open sidebar -->
            <button class="sidebar-toggler d-lg-none" aria-label="Abrir menú" type="button">
                <i class="fas fa-bars"></i>
            </button>
            	<div class="logo-text">
                <i class="fas fa-cogs"></i> IRM Maquinarias S.R.L.
            	</div>
        </div>
        <div class="user-info">
            <div>
                <div class="welcome-text">Bienvenido</div>
                <div class="user-name"><?php echo e(Auth::check() ? (Auth::user()->nombre ?: 'Usuario') : 'Invitado'); ?></div>
            </div>
            <?php if(Auth::check()): ?>
            <form action="<?php echo e(route('logout')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn-logout">
                    <i class="fas fa-sign-out-alt" aria-hidden="true"></i>
                    <span class="logout-text">Cerrar Sesión</span>
                </button>
            </form>
            <?php else: ?>
            <a href="<?php echo e(route('login')); ?>" class="btn-logout" style="text-decoration: none;">
                <i class="fas fa-sign-in-alt" aria-hidden="true"></i>
                <span class="logout-text">Iniciar Sesión</span>
            </a>
            <?php endif; ?>
        </div>
    </div>

    <!-- Sidebar -->
    <div class="sidebar animate-in">
        <div class="sidebar-header">
            <div class="brand">
                <div class="brand-icon">
                    <i class="fas fa-industry"></i>
                </div>
            </div>
            <h4>IRM Maquinarias S.R.L.</h4>
            <div class="brand-tagline">Sistema de Gestión</div>
        </div>

        <nav class="sidebar-nav">
            <div class="nav-section-title">MENÚ PRINCIPAL</div>
            <ul class="nav flex-column">
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('home') ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>">
                        <i class="fas fa-chart-pie"></i> Dashboard
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('compras.*') ? 'active' : ''); ?>" href="<?php echo e(route('compras.index')); ?>">
                        <i class="fas fa-shopping-bag"></i> Compras
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('ventas.*') ? 'active' : ''); ?>" href="<?php echo e(route('ventas.index')); ?>">
                        <i class="fas fa-cash-register"></i> Ventas
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('clientes.*') ? 'active' : ''); ?>" href="<?php echo e(route('clientes.index')); ?>">
                        <i class="fas fa-users"></i> Clientes
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?php echo e(request()->routeIs('productos.*') ? 'active' : ''); ?>" href="<?php echo e(route('productos.index')); ?>">
                        <i class="fas fa-boxes"></i> Productos
                    </a>
                </li>
                    </ul>

            <div class="nav-section-title">GESTIÓN</div>
            <div class="menu-item">
                <h5><i class="fas fa-box-open"></i> Gestión de Productos</h5>
                <div class="submenu">
                    <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2,3,4])): ?>
                    <a href="<?php echo e(route('productos.index')); ?>">
                        <i class="fas fa-boxes"></i> Productos
                    </a>
                    <a href="<?php echo e(route('categorias.index')); ?>">
                        <i class="fas fa-layer-group"></i> Categorías
                    </a>
                    <a href="<?php echo e(route('marcas.index')); ?>">
                        <i class="fas fa-tags"></i> Marcas
                    </a>
                    <?php endif; ?>
                    <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2,4])): ?>
                    <a href="<?php echo e(route('proveedores.index')); ?>">
                        <i class="fas fa-truck-loading"></i> Proveedores
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <div class="menu-item">
                <h5><i class="fas fa-shopping-cart"></i> Gestión de Ventas</h5>
                <div class="submenu">
                    <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2,3,5])): ?>
                    <a href="<?php echo e(route('ventas.index')); ?>">
                        <i class="fas fa-list-ul"></i> Ver Todas las Ventas
                    </a>
                    <?php endif; ?>
                    <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2,3])): ?>
                    <a href="<?php echo e(route('ventas.create')); ?>">
                        <i class="fas fa-plus-circle"></i> Nueva Venta
                    </a>
                    <a href="<?php echo e(route('clientes.index')); ?>">
                        <i class="fas fa-user-friends"></i> Gestionar Clientes
                    </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2,4])): ?>
            <div class="menu-item">
                <h5><i class="fas fa-shopping-bag"></i> Gestión de Compras</h5>
                <div class="submenu">
                    <a href="<?php echo e(route('compras.index')); ?>">
                        <i class="fas fa-clipboard-list"></i> Ver Todas las Compras
                    </a>
                    <a href="<?php echo e(route('compras.create')); ?>">
                        <i class="fas fa-plus-circle"></i> Nueva Compra
                    </a>
                </div>
            </div>
            <?php endif; ?>

            <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2])): ?>
            <div class="nav-section-title">ADMINISTRACIÓN</div>
            <div class="menu-item">
                <h5><i class="fas fa-cog"></i> Configuración</h5>
                <div class="submenu">
                    <a href="<?php echo e(route('monedas.index')); ?>">
                        <i class="fas fa-dollar-sign"></i> Monedas
                    </a>
                    <?php if(Auth::check() && Auth::user()->id_rol == 1): ?>
                    <a href="<?php echo e(route('usuarios.index')); ?>">
                        <i class="fas fa-users-cog"></i> Usuarios
                    </a>
                    <a href="<?php echo e(route('bitacoras.index')); ?>">
                        <i class="fas fa-book"></i> Bitácoras
                    </a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if(Auth::check() && in_array(Auth::user()->id_rol, [1,2,5])): ?>
            <div class="nav-section-title">REPORTES</div>
            <div class="menu-item">
                <h5><i class="fas fa-chart-line"></i> Reportes</h5>
                <div class="submenu">
                    <a href="<?php echo e(route('reportes.diario')); ?>">
                        <i class="fas fa-calendar-day"></i> Reporte Diario
                    </a>
                    <a href="<?php echo e(route('semanal')); ?>">
                        <i class="fas fa-calendar-week"></i> Reporte Semanal
                    </a>
                    <a href="<?php echo e(route('mensual')); ?>">
                        <i class="fas fa-calendar-alt"></i> Reporte Mensual
                    </a>
                    <a href="<?php echo e(route('trimestral')); ?>">
                        <i class="fas fa-calendar"></i> Reporte Trimestral
                    </a>
                    <a href="<?php echo e(route('reportes.semestral')); ?>">
                        <i class="fas fa-calendar-check"></i> Reporte Semestral
                    </a>
                    <a href="<?php echo e(route('reportes.anual')); ?>">
                        <i class="fas fa-chart-bar"></i> Reporte Anual
                    </a>
                </div>
            </div>
            <?php endif; ?>
        </nav>
    </div>

    <!-- Contenido Principal -->
    <div class="content animate-in">
        <div class="content-wrapper">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>

<!-- Scripts modernos -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>

<!-- Sección personalizada para estilos adicionales -->
<?php echo $__env->yieldContent('styles'); ?>

<!-- Script personalizado del layout -->
<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<!-- Sección personalizada para scripts adicionales -->
<?php echo $__env->yieldContent('scripts'); ?>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script>
    // Mobile sidebar toggle logic
    (function(){
        const toggler = document.querySelector('.sidebar-toggler');
        const sidebar = document.querySelector('.sidebar');
        if(!toggler || !sidebar) return;

        // Close when clicking outside sidebar — improved with overlay management
        function ensureOverlay(){
            let ov = document.getElementById('sidebar-overlay');
            if(!ov){
                ov = document.createElement('div');
                ov.id = 'sidebar-overlay';
                Object.assign(ov.style,{
                    position: 'fixed', inset: '0', background: 'rgba(0,0,0,0.32)', zIndex: '1000'
                });
                ov.addEventListener('click', closeSidebar);
                document.body.appendChild(ov);
            }
            return ov;
        }

        function removeOverlay(){
            const ov = document.getElementById('sidebar-overlay');
            if(ov) ov.remove();
        }

        // open/close handlers updated to manage overlay
        function openSidebar(){ sidebar.classList.add('show'); ensureOverlay(); document.body.style.overflow = 'hidden'; }
        function closeSidebar(){ sidebar.classList.remove('show'); removeOverlay(); document.body.style.overflow = ''; }

        toggler.addEventListener('click', (e)=>{
            e.stopPropagation();
            if(sidebar.classList.contains('show')) closeSidebar(); else openSidebar();
        });

        // Close on Escape
        document.addEventListener('keydown', (e)=>{ if(e.key === 'Escape') closeSidebar(); });

        // Close when clicking a navigation link (mobile)
        sidebar.querySelectorAll('.nav-link').forEach(a=>a.addEventListener('click', ()=>{ if(window.innerWidth<=768) closeSidebar(); }));
    })();
</script>
</body>
</html><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\layouts\dashboard.blade.php ENDPATH**/ ?>
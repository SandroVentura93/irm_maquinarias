

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Editar Categoría</h1>
    <form action="<?php echo e(route('categorias.update', $categoria->id_categoria)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" name="nombre" id="nombre" class="form-control" value="<?php echo e($categoria->nombre); ?>" required>
        </div>
        <div class="form-group">
            <label for="descripcion">Descripción</label>
            <textarea name="descripcion" id="descripcion" class="form-control"><?php echo e($categoria->descripcion); ?></textarea>
        </div>
        <div class="form-group">
            <label for="activo">Activo</label>
            <select name="activo" id="activo" class="form-control">
                <option value="1" <?php echo e($categoria->activo ? 'selected' : ''); ?>>Sí</option>
                <option value="0" <?php echo e(!$categoria->activo ? 'selected' : ''); ?>>No</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Actualizar</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\categorias\edit.blade.php ENDPATH**/ ?>
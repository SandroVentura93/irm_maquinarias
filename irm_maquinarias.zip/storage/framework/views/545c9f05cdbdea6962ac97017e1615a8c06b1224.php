

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header bg-danger text-white">
                    <h4><i class="fas fa-exclamation-triangle"></i> Confirmar Anulación de Venta</h4>
                </div>
                <div class="card-body">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <strong>Error:</strong> <?php echo e(session('error')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <strong>Éxito:</strong> <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
                    
                    <div class="alert alert-warning">
                        <strong>¡Atención!</strong> Esta acción anulará la venta y revertirá el stock de todos los productos. Esta operación no se puede deshacer.
                    </div>

                    <h5>Detalles de la Venta</h5>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <p><strong>Número:</strong> <?php echo e($venta->serie); ?>-<?php echo e($venta->numero); ?></p>
                            <p><strong>Fecha:</strong> <?php echo e(\Carbon\Carbon::parse($venta->fecha)->format('d/m/Y H:i')); ?></p>
                            <p><strong>Cliente:</strong> <?php echo e($venta->cliente->nombre); ?></p>
                        </div>
                        <div class="col-md-6">
                            <p><strong>Vendedor:</strong> <?php echo e($venta->vendedor ? $venta->vendedor->nombre : 'Sin asignar'); ?></p>
                            <p><strong>Estado Actual:</strong> 
                                <span class="badge badge-<?php echo e($venta->xml_estado === 'ACEPTADO' ? 'success' : 'info'); ?>">
                                    <?php echo e($venta->xml_estado); ?>

                                </span>
                            </p>
                            <p><strong>Total:</strong> <span class="text-success font-weight-bold">S/ <?php echo e(number_format($venta->total, 2)); ?></span></p>
                        </div>
                    </div>

                    <h5><i class="fas fa-boxes me-2 text-warning"></i>Productos que serán revertidos al stock</h5>
                    <div class="table-responsive">
                        <table class="table table-striped table-hover">
                            <thead class="table-dark">
                                <tr>
                                    <th><i class="fas fa-barcode me-1"></i>Código</th>
                                    <th><i class="fas fa-box me-1"></i>Producto</th>
                                    <th class="text-center"><i class="fas fa-arrow-up me-1"></i>Cantidad Vendida</th>
                                    <th class="text-center"><i class="fas fa-warehouse me-1"></i>Stock Actual</th>
                                    <th class="text-center"><i class="fas fa-plus-circle me-1"></i>Stock Después</th>
                                    <th class="text-end"><i class="fas fa-dollar-sign me-1"></i>Precio</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $totalReversion = 0; ?>
                                <?php if($venta->detalleVentas->isEmpty()): ?>
                                    <tr>
                                        <td colspan="6" class="text-center text-muted py-4">
                                            <i class="fas fa-exclamation-triangle fa-2x mb-2"></i><br>
                                            No se encontraron productos en esta venta
                                        </td>
                                    </tr>
                                <?php endif; ?>
                                <?php $__currentLoopData = $venta->detalleVentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="align-middle">
                                    <td>
                                        <strong class="text-primary"><?php echo e($detalle->producto ? $detalle->producto->codigo : 'N/A'); ?></strong>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-cog text-secondary me-2"></i>
                                            <span><?php echo e($detalle->producto ? $detalle->producto->descripcion : 'Producto no encontrado'); ?></span>
                                        </div>
                                    </td>
                                    <td class="text-center">
                                        <span class="badge bg-warning text-dark fs-6">
                                            <i class="fas fa-minus-circle me-1"></i><?php echo e(abs($detalle->cantidad)); ?>

                                        </span>
                                    </td>
                                    <td class="text-center">
                                        <?php if($detalle->producto): ?>
                                            <span class="fw-bold text-info"><?php echo e(number_format($detalle->producto->stock_actual, 0)); ?></span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-center">
                                        <?php if($detalle->producto): ?>
                                            <span class="badge bg-success fs-6">
                                                <i class="fas fa-plus-circle me-1"></i><?php echo e(number_format($detalle->producto->stock_actual + abs($detalle->cantidad), 0)); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="text-muted">N/A</span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="text-end">
                                        <strong class="text-success">S/ <?php echo e(number_format($detalle->total, 2)); ?></strong>
                                    </td>
                                </tr>
                                <?php $totalReversion += $detalle->total; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot class="table-secondary">
                                <tr>
                                    <th colspan="5" class="text-end">
                                        <i class="fas fa-calculator me-2 text-success"></i>
                                        <strong>Total a Revertir:</strong>
                                    </th>
                                    <th class="text-end">
                                        <strong class="fs-5 text-success">S/ <?php echo e(number_format($totalReversion, 2)); ?></strong>
                                    </th>
                                </tr>
                            </tfoot>
                        </table>
                    </div>

                    <div class="mt-4">
                        <div class="row">
                            <div class="col-md-6">
                                <a href="<?php echo e(route('ventas.index')); ?>" class="btn btn-secondary btn-block">
                                    <i class="fas fa-arrow-left"></i> Cancelar y Volver
                                </a>
                            </div>
                            <div class="col-md-6">
                                <form action="<?php echo e(route('ventas.cancel', $venta)); ?>" method="POST" id="cancelForm">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="motivo" value="Anulación desde interfaz web">
                                    <button type="button" class="btn btn-danger btn-block" id="confirmButton">
                                        <i class="fas fa-times"></i> Confirmar Anulación
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM cargado - iniciando script de cancelación');
    
    var form = document.getElementById('cancelForm');
    var button = document.getElementById('confirmButton');
    
    console.log('Formulario encontrado:', form);
    console.log('Botón encontrado:', button);
    console.log('Acción del formulario:', form ? form.action : 'No encontrado');
    console.log('Método del formulario:', form ? form.method : 'No encontrado');
    
    if (button && form) {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Botón de cancelación clickeado');
            
            // Confirmar la acción
            if (confirm('¿Estás completamente seguro de anular esta venta?\n\nEsta acción:\n- Cambiará el estado a ANULADO\n- Revertirá el stock de todos los productos\n- NO se puede deshacer\n\n¿Continuar?')) {
                console.log('Usuario confirmó la anulación');
                
                // Deshabilitar botón y mostrar estado de carga
                button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Anulando venta...';
                button.disabled = true;
                
                // Debug: mostrar datos del formulario
                console.log('Enviando formulario...');
                console.log('URL destino:', form.action);
                console.log('Método:', form.method);
                
                // Verificar que tenemos CSRF token
                var csrfToken = form.querySelector('input[name="_token"]');
                console.log('CSRF Token encontrado:', csrfToken ? csrfToken.value : 'NO');
                
                var methodInput = form.querySelector('input[name="_method"]');
                console.log('Method input encontrado:', methodInput ? methodInput.value : 'NO');
                
                // Enviar formulario
                try {
                    form.submit();
                    console.log('Formulario enviado exitosamente');
                } catch (error) {
                    console.error('Error al enviar formulario:', error);
                    button.innerHTML = '<i class="fas fa-times"></i> Error - Reintentar';
                    button.disabled = false;
                    alert('Error al enviar el formulario. Por favor, intenta nuevamente.');
                }
            } else {
                console.log('Usuario canceló la operación');
            }
        });
        
        console.log('Event listener agregado exitosamente');
    } else {
        console.error('Error: No se pudo encontrar el formulario o el botón');
        console.error('Elementos en el DOM:');
        console.error('- Formularios:', document.querySelectorAll('form').length);
        console.error('- Botones:', document.querySelectorAll('button').length);
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Administrador\irm_maquinarias\resources\views/ventas/confirm-cancel.blade.php ENDPATH**/ ?>
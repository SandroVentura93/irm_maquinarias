


<?php $__env->startSection('content'); ?>
<style>
    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
        padding-bottom: 1rem;
        border-bottom: 3px solid #dc2626;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        display: flex;
        align-items: center;
        gap: 0.75rem;
        margin: 0;
    }

    .breadcrumb-custom {
        background: transparent;
        padding: 0;
        margin: 0;
        font-size: 0.875rem;
    }

    .breadcrumb-custom a {
        color: #dc2626;
        text-decoration: none;
        transition: all 0.3s ease;
    }

    .breadcrumb-custom a:hover {
        color: #991b1b;
    }

    .btn-back {
        background: #6b7280;
        color: white;
        border: none;
        border-radius: 10px;
        padding: 0.625rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }

    .btn-back:hover {
        background: #4b5563;
        transform: translateY(-2px);
        color: white;
    }

    .id-badge-large {
        background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%);
        color: white;
        padding: 0.75rem 1.5rem;
        border-radius: 12px;
        font-weight: 700;
        font-size: 1.5rem;
        display: inline-block;
        box-shadow: 0 4px 6px rgba(220, 38, 38, 0.3);
    }

    .card-modern {
        border-radius: 16px;
        border: none;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
        overflow: hidden;
        margin-bottom: 2rem;
        background: white;
    }

    .card-header-gradient {
        background: linear-gradient(135deg, #dc2626 0%, #991b1b 100%);
        color: white;
        padding: 1.5rem;
        border: none;
    }

    .card-header-gradient h5 {
        margin: 0;
        font-weight: 700;
        font-size: 1.25rem;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .card-body-custom {
        padding: 2rem;
    }

    .info-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 1.5rem;
        margin-bottom: 2rem;
    }

    .info-item {
        background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
        padding: 1.25rem;
        border-radius: 12px;
        border-left: 4px solid #dc2626;
        transition: all 0.3s ease;
    }

    .info-item:hover {
        transform: translateX(4px);
        box-shadow: 0 4px 8px rgba(220, 38, 38, 0.15);
    }

    .info-label {
        font-size: 0.875rem;
        color: #6b7280;
        font-weight: 600;
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .info-label i {
        color: #dc2626;
    }

    .info-value {
        font-size: 1.125rem;
        color: #111827;
        font-weight: 700;
    }

    .totals-section {
        background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
        border-radius: 12px;
        padding: 2rem;
        margin-bottom: 2rem;
    }

    .total-row {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1rem 0;
        border-bottom: 2px dashed #fde68a;
    }

    .total-row:last-child {
        border-bottom: none;
        padding-top: 1.5rem;
        margin-top: 1rem;
        border-top: 3px solid #f59e0b;
    }

    .total-label {
        font-size: 1rem;
        font-weight: 600;
        color: #374151;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .total-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #dc2626;
    }

    .total-row:last-child .total-label {
        font-size: 1.25rem;
    }

    .total-row:last-child .total-value {
        font-size: 2rem;
        color: #059669;
    }

    .table-modern {
        margin: 0;
    }

    .table-modern thead {
        background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
    }

    .table-modern thead th {
        border: none;
        padding: 1rem;
        font-weight: 600;
        color: #991b1b;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        font-size: 0.875rem;
    }

    .table-modern tbody td {
        padding: 1rem;
        vertical-align: middle;
        border-bottom: 1px solid #f3f4f6;
    }

    .table-modern tbody tr {
        transition: all 0.2s ease;
    }

    .table-modern tbody tr:hover {
        background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 50%);
    }

    .table-modern tbody tr:last-child td {
        border-bottom: none;
    }

    /* Mobile: stacked product list */
    @media (max-width: 768px) {
        .card-body-custom { padding: 1rem; }
        .table-modern thead { display: none; }
        .table-modern, .table-modern tbody, .table-modern tr, .table-modern td { display: block; width: 100%; }
        .table-modern tr { margin-bottom: 0.75rem; border-bottom: 1px solid #eee; padding-bottom: 0.5rem; }
        .table-modern td { padding: 0.5rem 0; display: flex; justify-content: space-between; align-items: center; }
        .table-modern td:before { content: attr(data-label); font-weight: 600; color: #6b7280; margin-right: 0.5rem; }
        .info-grid { grid-template-columns: 1fr; }
        .totals-section { padding: 1rem; }
    }

    /* Extra mobile polish: scale fonts, make totals full width and stack properly */
    @media (max-width: 768px) {
        .page-title { font-size: 1.15rem; }
        .card-header-gradient h5 { font-size: 1rem; }
        .info-value { font-size: 1rem; }
        .stat-value { font-size: 1.25rem; }
        .totals-section { padding: 1rem; box-shadow: none; border-radius: 8px; }
        /* Ensure the totals column doesn't offset on small screens */
        .row > .col-lg-6.offset-lg-6 { margin-left: 0 !important; width: 100% !important; }
        /* Make totals labels smaller and align stack */
        .total-label { font-size: 0.95rem; }
        .total-value { font-size: 1.05rem; }
        /* Action buttons stack and stretch */
        .actions-bar { flex-direction: column; gap: 0.5rem; }
        .actions-bar .btn-action { width: 100%; }
        /* Improve product card readability on tiny screens */
        .product-name { font-size: 0.95rem; }
        .quantity-badge { padding: 0.25rem 0.5rem; font-size: 0.9rem; }
    }

    /* Header tweaks for mobile in show view */
    @media (max-width: 768px) {
        .page-header { flex-direction: column; align-items: flex-start; gap: 0.5rem; }
        .page-header .page-title { font-size: 1.25rem; }
        .page-header .page-title i { font-size: 1rem; }
        .actions-bar { width: 100%; display:flex; gap:0.5rem; }
        .actions-bar .btn-action { flex: 1; justify-content:center; }
    }

    .product-name {
        font-weight: 600;
        color: #111827;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .product-name i {
        color: #dc2626;
    }

    .quantity-badge {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        padding: 0.375rem 0.75rem;
        border-radius: 8px;
        font-weight: 700;
        display: inline-block;
    }

    .price-cell {
        font-weight: 600;
        color: #374151;
    }

    .total-cell {
        font-weight: 700;
        color: #dc2626;
        font-size: 1.05rem;
    }

    .estado-badge {
        padding: 0.5rem 1rem;
        border-radius: 8px;
        font-weight: 700;
        font-size: 1rem;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }

    .estado-completado {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
    }

    .estado-pendiente {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: white;
    }

    .estado-cancelado {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: white;
    }

    .empty-state {
        padding: 4rem 2rem;
        text-align: center;
    }

    .empty-state-icon {
        font-size: 4rem;
        color: #d1d5db;
        margin-bottom: 1rem;
    }

    .empty-state-text {
        color: #6b7280;
        font-size: 1.125rem;
    }

    .actions-bar {
        display: flex;
        gap: 1rem;
        margin-bottom: 2rem;
    }

    .btn-action {
        border-radius: 10px;
        padding: 0.75rem 1.5rem;
        font-weight: 600;
        transition: all 0.3s ease;
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
        border: none;
    }

    .btn-edit {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: white;
    }

    .btn-edit:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(245, 158, 11, 0.3);
        color: white;
    }

    .btn-delete {
        background: linear-gradient(135deg, #ef4444 0%, #dc2626 100%);
        color: white;
    }

    .btn-delete:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 8px rgba(239, 68, 68, 0.3);
        color: white;
    }

    .stats-summary {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 1rem;
        margin-bottom: 2rem;
    }

    .stat-card {
        background: white;
        border-radius: 12px;
        padding: 1.25rem;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
        text-align: center;
        transition: all 0.3s ease;
    }

    .stat-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 8px 16px rgba(220, 38, 38, 0.15);
    }

    .stat-icon {
        width: 50px;
        height: 50px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        margin: 0 auto 0.75rem;
        font-size: 1.5rem;
    }

    .stat-icon.productos {
        background: linear-gradient(135deg, #8b5cf6 0%, #7c3aed 100%);
        color: white;
    }

    .stat-icon.cantidad {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
    }

    .stat-icon.promedio {
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: white;
    }

    .stat-label {
        font-size: 0.875rem;
        color: #6b7280;
        font-weight: 600;
        margin-bottom: 0.25rem;
    }

    .stat-value {
        font-size: 1.5rem;
        font-weight: 700;
        color: #111827;
    }
</style>

<div class="container-fluid px-4 py-4">
    <div class="page-header">
        <div>
            <nav aria-label="breadcrumb" class="breadcrumb-custom mb-2">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('compras.index')); ?>"><i class="fas fa-shopping-cart me-1"></i>Compras</a></li>
                    <li class="breadcrumb-item active">Detalle</li>
                </ol>
            </nav>
            <h1 class="page-title">
                <i class="fas fa-file-invoice"></i>
                Detalle de Compra
            </h1>
        </div>
        <a href="<?php echo e(route('compras.index')); ?>" class="btn-back">
            <i class="fas fa-arrow-left"></i>
            Volver al Listado
        </a>
    </div>

    <!-- ID y Acciones -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <span class="id-badge-large">
            <i class="fas fa-hashtag me-2"></i><?php echo e($compra->id_compra); ?>

        </span>
        <div class="actions-bar">
            <a href="<?php echo e(route('compras.edit', $compra->id_compra)); ?>" class="btn-action btn-edit">
                <i class="fas fa-edit"></i>
                Editar Compra
            </a>
            <form action="<?php echo e(route('compras.destroy', $compra->id_compra)); ?>" method="POST" class="d-inline" onsubmit="return confirm('¿Está seguro de eliminar esta compra?')">
                <?php echo csrf_field(); ?>
                <?php echo method_field('DELETE'); ?>
                <button type="submit" class="btn-action btn-delete">
                    <i class="fas fa-trash"></i>
                    Eliminar
                </button>
            </form>
        </div>
    </div>

    <!-- Información General -->
    <div class="card-modern">
        <div class="card-header-gradient">
            <h5>
                <i class="fas fa-info-circle"></i>
                Información de la Compra
            </h5>
        </div>
        <div class="card-body-custom">
            <div class="info-grid">
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-building"></i>
                        Proveedor
                    </div>
                    <div class="info-value"><?php echo e($compra->proveedor->razon_social ?? '-'); ?></div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-coins"></i>
                        Moneda
                    </div>
                    <div class="info-value"><?php echo e($compra->moneda->nombre ?? $compra->moneda->descripcion ?? '-'); ?></div>
                </div>
                
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-calendar-alt"></i>
                        Fecha de Compra
                    </div>
                    <div class="info-value"><?php echo e(Carbon\Carbon::parse($compra->fecha)->format('d/m/Y H:i')); ?></div>
                </div>
                
                <?php if(isset($compra->estado)): ?>
                <div class="info-item">
                    <div class="info-label">
                        <i class="fas fa-check-circle"></i>
                        Estado
                    </div>
                    <div class="info-value">
                        <span class="estado-badge estado-completado">
                            <i class="fas fa-check"></i>
                            <?php echo e($compra->estado); ?>

                        </span>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Estadísticas de Productos -->
    <?php
        $totalProductos = $compra->detalles->count();
        $totalCantidad = $compra->detalles->sum('cantidad');
        $promedioPrecio = $totalProductos > 0 ? $compra->total / $totalCantidad : 0;
    ?>
    
    <div class="stats-summary">
        <?php
            $simbolo = $compra->moneda->simbolo ?? 'S/';
            $codigoIso = $compra->moneda->codigo_iso ?? 'PEN';
            $icono = $codigoIso === 'USD' ? 'fas fa-dollar-sign' : 'fas fa-money-bill-wave';
        ?>
        <div class="stat-card">
            <div class="stat-icon productos">
                <i class="fas fa-boxes"></i>
            </div>
            <div class="stat-label">Productos Diferentes</div>
            <div class="stat-value"><?php echo e($totalProductos); ?></div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon cantidad">
                <i class="fas fa-cubes"></i>
            </div>
            <div class="stat-label">Cantidad Total</div>
            <div class="stat-value"><?php echo e($totalCantidad); ?></div>
        </div>
        
        <div class="stat-card">
            <div class="stat-icon promedio">
                <i class="fas fa-calculator"></i>
            </div>
            <div class="stat-label">Precio Promedio <span class="badge bg-secondary"><?php echo e($codigoIso); ?></span></div>
            <div class="stat-value"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($promedioPrecio, 2)); ?></div>
        </div>
    </div>

    <!-- Productos -->
    <div class="card-modern">
        <div class="card-header-gradient">
            <h5>
                <i class="fas fa-list"></i>
                Productos Comprados
            </h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-modern">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th class="text-center">Cantidad</th>
                            <th class="text-end">Precio Unitario</th>
                            <th class="text-end">Subtotal</th>
                            <th class="text-end">IGV (18%)</th>
                            <th class="text-end">Total</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $compra->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="Producto">
                                <div class="product-name">
                                    <i class="fas fa-box"></i>
                                    <?php echo e($detalle->producto->descripcion ?? $detalle->producto->nombre ?? '-'); ?>

                                </div>
                            </td>
                            <td data-label="Cantidad" class="text-center">
                                <span class="quantity-badge"><?php echo e($detalle->cantidad); ?></span>
                            </td>
                            <td data-label="Precio" class="text-end price-cell"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($detalle->precio_unitario, 2)); ?></td>
                            <td data-label="Subtotal" class="text-end price-cell"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($detalle->subtotal, 2)); ?></td>
                            <td data-label="IGV" class="text-end price-cell"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($detalle->igv, 2)); ?></td>
                            <td data-label="Total" class="text-end total-cell"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($detalle->total, 2)); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6">
                                <div class="empty-state">
                                    <div class="empty-state-icon">
                                        <i class="fas fa-box-open"></i>
                                    </div>
                                    <p class="empty-state-text">No hay productos registrados en esta compra</p>
                                </div>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Totales -->
    <div class="row">
        <div class="col-lg-6 offset-lg-6">
            <div class="totals-section">
                <div class="total-row">
                    <span class="total-label">
                        <i class="fas fa-file-invoice-dollar"></i>
                        Subtotal:
                    </span>
                    <span class="total-value" style="font-size: 1.25rem;"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($compra->subtotal, 2)); ?></span>
                </div>
                
                <div class="total-row">
                    <span class="total-label">
                        <i class="fas fa-percentage"></i>
                        IGV (18%):
                    </span>
                    <span class="total-value" style="font-size: 1.25rem;"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($compra->igv, 2)); ?></span>
                </div>
                
                <div class="total-row">
                    <span class="total-label">
                        <i class="fas fa-money-bill-wave"></i>
                        TOTAL:
                    </span>
                    <span class="total-value"><i class="<?php echo e($icono); ?> me-1"></i> <?php echo e($simbolo); ?> <?php echo e(number_format($compra->total, 2)); ?></span>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\compras\show.blade.php ENDPATH**/ ?>
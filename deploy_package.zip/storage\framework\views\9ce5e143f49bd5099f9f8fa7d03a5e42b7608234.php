<?php if($paginator->hasPages()): ?>
    <nav class="modern-pagination" role="navigation" aria-label="<?php echo e(__('Pagination Navigation')); ?>">
        <div class="pagination-wrapper">
            
            <?php if($paginator->onFirstPage()): ?>
                <span class="pagination-item disabled">
                    <i class="fas fa-chevron-left"></i>
                    <span class="sr-only"><?php echo e(__('pagination.previous')); ?></span>
                </span>
            <?php else: ?>
                <a href="<?php echo e($paginator->previousPageUrl()); ?>" class="pagination-item" rel="prev" aria-label="<?php echo e(__('pagination.previous')); ?>">
                    <i class="fas fa-chevron-left"></i>
                    <span class="sr-only"><?php echo e(__('pagination.previous')); ?></span>
                </a>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <span class="pagination-item dots" aria-disabled="true"><?php echo e($element); ?></span>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <span class="pagination-item active" aria-current="page"><?php echo e($page); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e($url); ?>" class="pagination-item" aria-label="<?php echo e(__('Go to page :page', ['page' => $page])); ?>"><?php echo e($page); ?></a>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <a href="<?php echo e($paginator->nextPageUrl()); ?>" class="pagination-item" rel="next" aria-label="<?php echo e(__('pagination.next')); ?>">
                    <i class="fas fa-chevron-right"></i>
                    <span class="sr-only"><?php echo e(__('pagination.next')); ?></span>
                </a>
            <?php else: ?>
                <span class="pagination-item disabled">
                    <i class="fas fa-chevron-right"></i>
                    <span class="sr-only"><?php echo e(__('pagination.next')); ?></span>
                </span>
            <?php endif; ?>
        </div>

        
        <div class="pagination-info">
            <p class="text-sm text-gray-600">
                <?php echo __('Showing'); ?>

                <?php if($paginator->firstItem()): ?>
                    <span class="font-medium"><?php echo e($paginator->firstItem()); ?></span>
                    <?php echo __('to'); ?>

                    <span class="font-medium"><?php echo e($paginator->lastItem()); ?></span>
                <?php else: ?>
                    <?php echo e($paginator->count()); ?>

                <?php endif; ?>
                <?php echo __('of'); ?>

                <span class="font-medium"><?php echo e($paginator->total()); ?></span>
                <?php echo __('results'); ?>

            </p>
        </div>
    </nav>
<?php endif; ?><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\custom-pagination.blade.php ENDPATH**/ ?>
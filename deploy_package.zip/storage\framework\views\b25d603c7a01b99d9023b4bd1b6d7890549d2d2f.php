

<?php $__env->startSection('content'); ?>
<div class="container-fluid py-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card border-0 shadow-lg">
                <div class="card-body text-center p-5">
                    <!-- Icono de Error -->
                    <div class="mb-4">
                        <?php if($code == 404): ?>
                            <i class="fas fa-search text-warning" style="font-size: 4rem;"></i>
                        <?php elseif($code == 500): ?>
                            <i class="fas fa-exclamation-triangle text-danger" style="font-size: 4rem;"></i>
                        <?php else: ?>
                            <i class="fas fa-exclamation-circle text-info" style="font-size: 4rem;"></i>
                        <?php endif; ?>
                    </div>
                    
                    <!-- Código de Error -->
                    <h1 class="display-4 text-muted mb-3"><?php echo e($code); ?></h1>
                    
                    <!-- Mensaje -->
                    <h4 class="mb-4">
                        <?php if($code == 404): ?>
                            Página No Encontrada
                        <?php elseif($code == 500): ?>
                            Error del Servidor
                        <?php else: ?>
                            Error <?php echo e($code); ?>

                        <?php endif; ?>
                    </h4>
                    
                    <p class="text-muted mb-4"><?php echo e($message); ?></p>
                    
                    <!-- Sugerencias -->
                    <div class="alert alert-light border-0 mb-4">
                        <h6 class="mb-2">💡 Sugerencias:</h6>
                        <ul class="list-unstyled text-start mb-0">
                            <?php if($code == 404): ?>
                                <li>• Verifique la URL ingresada</li>
                                <li>• Use la navegación del menú</li>
                                <li>• Contacte al administrador si el problema persiste</li>
                            <?php elseif($code == 500): ?>
                                <li>• Intente recargar la página</li>
                                <li>• Verifique su conexión a internet</li>
                                <li>• Contacte al soporte técnico</li>
                            <?php else: ?>
                                <li>• Intente la operación nuevamente</li>
                                <li>• Verifique los datos ingresados</li>
                                <li>• Contacte al administrador</li>
                            <?php endif; ?>
                        </ul>
                    </div>
                    
                    <!-- Acciones -->
                    <div class="d-flex gap-3 justify-content-center">
                        <button onclick="window.history.back()" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i>
                            Regresar
                        </button>
                        
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-primary">
                            <i class="fas fa-home me-2"></i>
                            Ir al Dashboard
                        </a>
                        
                        <button onclick="window.location.reload()" class="btn btn-outline-success">
                            <i class="fas fa-sync-alt me-2"></i>
                            Recargar
                        </button>
                    </div>
                    
                    <!-- Información adicional -->
                    <?php if(app()->environment('local')): ?>
                        <div class="mt-4 pt-3 border-top">
                            <small class="text-muted">
                                Timestamp: <?php echo e(now()->format('Y-m-d H:i:s')); ?>

                            </small>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.card {
    border-radius: 15px;
}

.btn {
    border-radius: 25px;
    padding: 10px 20px;
}

.alert {
    border-radius: 10px;
}

@media (max-width: 576px) {
    .d-flex.gap-3 {
        flex-direction: column;
    }
    
    .d-flex.gap-3 .btn {
        margin-bottom: 10px;
    }
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\errors\custom.blade.php ENDPATH**/ ?>
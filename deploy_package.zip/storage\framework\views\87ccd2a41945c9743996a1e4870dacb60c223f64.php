<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NOTA DE DÉBITO - <?php echo e($venta->numero); ?></title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            color: #333;
        }
        
        .container {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
        }
        
        .header {
            display: table;
            width: 100%;
            margin-bottom: 20px;
            border-bottom: 2px solid #fd7e14;
            padding-bottom: 15px;
        }
        
        .company-info {
            display: table-cell;
            width: 60%;
            vertical-align: top;
        }
        
        .company-logo {
            width: 120px;
            height: 80px;
            background: #fff3cd;
            border: 2px solid #fd7e14;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 10px;
            font-size: 10px;
            color: #fd7e14;
            font-weight: bold;
        }
        
        .company-details h2 {
            color: #fd7e14;
            margin-bottom: 5px;
            font-size: 18px;
        }
        
        .document-info {
            display: table-cell;
            width: 35%;
            vertical-align: top;
            text-align: center;
            border: 2px solid #fd7e14;
            padding: 15px;
            background: #fff3cd;
        }
        
        .document-info h1 {
            color: #fd7e14;
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        .document-number {
            font-size: 16px;
            font-weight: bold;
            color: #fd7e14;
            margin-bottom: 10px;
        }
        
        .motivo-nota {
            background: #fff3cd;
            border-left: 4px solid #fd7e14;
            padding: 10px;
            margin: 15px 0;
        }
        
        .client-info {
            background: #f8f9fa;
            padding: 15px;
            margin: 20px 0;
            border-left: 4px solid #fd7e14;
        }
        
        .client-info h3 {
            color: #fd7e14;
            margin-bottom: 10px;
            font-size: 14px;
        }
        
        .details-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }
        
        .details-table th {
            background: #fd7e14;
            color: white;
            padding: 10px;
            text-align: center;
            font-size: 11px;
        }
        
        .details-table td {
            padding: 8px;
            border: 1px solid #ddd;
            text-align: center;
            font-size: 11px;
        }
        
        .details-table .description {
            text-align: left;
        }
        
        .details-table .amount {
            text-align: right;
            font-weight: bold;
            color: #fd7e14;
        }
        
        .totals {
            display: table;
            width: 100%;
            margin-top: 20px;
        }
        
        .totals-left {
            display: table-cell;
            width: 60%;
            vertical-align: top;
            padding-right: 20px;
        }
        
        .totals-right {
            display: table-cell;
            width: 40%;
            vertical-align: top;
        }
        
        .total-letras {
            background: #f8f9fa;
            padding: 10px;
            border: 1px solid #ddd;
            margin-bottom: 15px;
        }
        
        .observaciones {
            background: #f8f9fa;
            padding: 10px;
            border-left: 4px solid #fd7e14;
        }
        
        .totals-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .totals-table td {
            padding: 8px 12px;
            border: 1px solid #ddd;
        }
        
        .totals-table .label {
            background: #f8f9fa;
            font-weight: bold;
            text-align: right;
        }
        
        .totals-table .value {
            text-align: right;
            color: #fd7e14;
            font-weight: bold;
        }
        
        .totals-table .total {
            background: #fd7e14;
            color: white;
            font-weight: bold;
            font-size: 14px;
        }
        
        .footer {
            margin-top: 30px;
            text-align: center;
            font-size: 10px;
            color: #666;
            border-top: 1px solid #ddd;
            padding-top: 15px;
        }
        
        .text-right { text-align: right; }
        .text-center { text-align: center; }
        .font-bold { font-weight: bold; }
    </style>
</head>
<body>
    <div class="container">
        <!-- Header -->
        <div class="header">
            <div class="company-info">
                <?php echo $__env->make('comprobantes.partials.logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="company-details">
                    <h2><?php echo e($empresa['razon_social'] ?? 'IRM Maquinarias S.R.L.'); ?></h2>
                    <p><strong>RUC:</strong> <?php echo e($empresa['ruc'] ?? '20570639553'); ?></p>
                    <p><strong>Dirección:</strong> <?php echo e($empresa['direccion'] ?? 'AV. ATAHUALPA NRO. 725, CAJAMARCA'); ?></p>
                    <p><strong>Teléfono:</strong> <?php echo e($empresa['telefono'] ?? '976390506 - 974179198'); ?></p>
                    <p><strong>Email:</strong> <?php echo e($empresa['email'] ?? 'ventas@irmmaquinarias.com'); ?></p>
                </div>
            </div>
            
            <div class="document-info">
                <h1><?php echo e($tipoConfig['titulo'] ?? 'NOTA DE DÉBITO ELECTRÓNICA'); ?></h1>
                <div class="document-number"><?php echo e($venta->numero); ?></div>
                <p><strong>Código SUNAT:</strong> <?php echo e($tipoConfig['codigo_sunat'] ?? '08'); ?></p>
            </div>
        </div>

        <!-- Motivo de la nota de débito -->
        <div class="motivo-nota">
            <h4>📋 MOTIVO DE LA NOTA DE DÉBITO</h4>
            <p><strong>Código:</strong> 01 - Intereses por mora</p>
            <p><strong>Descripción:</strong> Cargo adicional por servicios</p>
            <p><strong>Documento de referencia:</strong> Factura F001-00000001</p>
        </div>

        <!-- Información del cliente -->
        <div class="client-info">
            <h3>INFORMACIÓN DEL CLIENTE</h3>
            <p><strong>Razón Social/Nombre:</strong> <?php echo e($venta->cliente->nombre ?? 'Cliente General'); ?></p>
            <p><strong>RUC/DNI:</strong> <?php echo e($venta->cliente->numero_documento ?? 'Sin documento'); ?></p>
            <p><strong>Dirección:</strong> <?php echo e($venta->cliente->direccion ?? 'Sin dirección'); ?></p>
        </div>

        <!-- Información de la nota -->
        <div style="display: table; width: 100%; margin: 15px 0;">
            <div style="display: table-cell; width: 33.33%; padding: 5px;">
                <p><strong>Fecha de Emisión:</strong> <?php echo e($venta->fecha->format('d/m/Y')); ?></p>
                <p><strong>Hora:</strong> <?php echo e($venta->fecha->format('H:i:s')); ?></p>
            </div>
            <div style="display: table-cell; width: 33.33%; padding: 5px;">
                <?php
                    $codigoIso = is_object($venta->moneda) ? ($venta->moneda->codigo_iso ?? 'PEN') : ($venta->moneda ?? 'PEN');
                    $simbolo = $codigoIso === 'USD' ? '$' : 'S/';
                ?>
                <p><strong>Moneda:</strong> <?php echo e($codigoIso === 'USD' ? 'Dólares Americanos' : 'Soles Peruanos'); ?> <span style="display:inline-block; padding:2px 6px; background:#2c5aa0; color:white; border-radius:4px; font-size:10px;"><?php echo e($codigoIso); ?></span></p>
                <?php if($codigoIso === 'USD'): ?>
                    <p><strong>Tipo de Cambio (referencial):</strong> S/ <?php echo e(number_format($venta->tipo_cambio ?? 3.75, 2)); ?> por USD</p>
                <?php endif; ?>
            </div>
            <div style="display: table-cell; width: 33.33%; padding: 5px;">
                <p><strong>Usuario:</strong> <?php echo e(auth()->user()->name ?? 'Sistema'); ?></p>
                <p><strong>Motivo SUNAT:</strong> 01 - Intereses por mora</p>
            </div>
        </div>

        <!-- Detalle de cargos -->
        <table class="details-table">
            <thead>
                <tr>
                    <th style="width: 8%;">Item</th>
                    <th style="width: 40%;">Descripción del Cargo</th>
                    <th style="width: 10%;">Cantidad</th>
                    <th style="width: 15%;">Precio Unitario</th>
                    <th style="width: 15%;">Importe</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $venta->detalleVenta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td class="description">
                        <strong>Cargo adicional: <?php echo e($detalle->producto->descripcion); ?></strong><br>
                        <small style="color: #fd7e14;">💰 CARGO ADICIONAL: Por servicios extras</small>
                    </td>
                    <td style="color: #fd7e14; font-weight: bold;">+<?php echo e(number_format($detalle->cantidad, 2)); ?></td>
                    <td class="text-right"><?php echo e($simbolo); ?> <?php echo e(number_format($detalle->precio_unitario, 2)); ?></td>
                    <td class="amount">
                        <?php
                            $subtotal_item = $detalle->cantidad * $detalle->precio_unitario * (1 - $detalle->descuento_porcentaje/100);
                        ?>
                        +<?php echo e($simbolo); ?> <?php echo e(number_format($subtotal_item, 2)); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Totales -->
        <div class="totals">
            <div class="totals-left">
                <div class="total-letras">
                    <h4>IMPORTE DE LA NOTA EN LETRAS:</h4>
                    <p class="font-bold"><?php echo e($datos['total_en_letras'] ?? 'CIEN CON 00/100 SOLES'); ?></p>
                </div>
                
                <div class="observaciones">
                    <h4>INFORMACIÓN SOBRE EL CARGO ADICIONAL:</h4>
                    <p>• Esta Nota de Débito incrementa el monto del documento de referencia</p>
                    <p>• El importe adicional debe ser cancelado junto con la deuda principal</p>
                    <p>• Cargo aplicado según términos y condiciones comerciales</p>
                    <p>• Para consultas contactar con el área de cobranzas</p>
                </div>
            </div>
            
            <div class="totals-right">
                <table class="totals-table">
                    <tr>
                        <td class="label">Operación Gravada:</td>
                        <td class="value">+<?php echo e($simbolo); ?> <?php echo e(number_format($datos['base_imponible'] ?? 0, 2)); ?></td>
                    </tr>
                    <tr>
                        <td class="label">IGV (18%):</td>
                        <td class="value">+<?php echo e($simbolo); ?> <?php echo e(number_format($datos['igv'] ?? 0, 2)); ?></td>
                    </tr>
                    <tr class="total">
                        <td class="total">TOTAL NOTA DÉBITO:</td>
                        <td class="total">+<?php echo e($simbolo); ?> <?php echo e(number_format($datos['total'] ?? 0, 2)); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">
            <p style="color: #fd7e14; font-weight: bold;">NOTA DE DÉBITO ELECTRÓNICA - DOCUMENTO OFICIAL SUNAT</p>
            <p>Este documento incrementa el importe del comprobante de referencia según la normativa tributaria vigente</p>
            <p><?php echo e($empresa['web'] ?? 'www.irmmaquinarias.com'); ?> | <?php echo e($empresa['email'] ?? 'ventas@irmmaquinarias.com'); ?> | Teléfono: <?php echo e($empresa['telefono'] ?? '(01) 234-5678'); ?></p>
            <p>Fecha y hora de generación: <?php echo e(now()->format('d/m/Y H:i:s')); ?></p>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\SANDRO VENTURA\irm_maquinarias\resources\views\comprobantes\nota_debito.blade.php ENDPATH**/ ?>